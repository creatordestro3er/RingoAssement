﻿namespace WebApplication1.Model
{
    public class EmailModel
    {
    }
}
