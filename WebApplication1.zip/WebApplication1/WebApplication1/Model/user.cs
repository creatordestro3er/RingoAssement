﻿namespace WebApplication1.Model
{
    public class user
    {
        public int ID { get; set; }
        public string Name{ get; set; }
        public string Email { get; set; }

        public string department { get; set; }




    }
}
